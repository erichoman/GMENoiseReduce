# GMENoiseReduce
Python implementation of the Generalized Maximum Entropy white noise elimination technique discussed in https://pubs.aip.org/aip/jap/article/132/7/074903/2837401/Eliminating-white-noise-in-spectra-A-generalized
